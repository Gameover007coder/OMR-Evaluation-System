import sqlite3
import json
import os
from datetime import datetime

class Database:
    def __init__(self):
        base_dir = os.path.dirname(os.path.abspath(__file__))
        self.db_path = os.path.join(base_dir, "db", "database.sqlite")
        os.makedirs(os.path.dirname(self.db_path), exist_ok=True)  # ensure folder exists
        self.init_db()
    
    def init_db(self):
        """Initialize the database with required tables"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Create results table
        cursor.execute('''
        CREATE TABLE IF NOT EXISTS results (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id TEXT NOT NULL,
            student_name TEXT NOT NULL,
            exam_date TEXT DEFAULT CURRENT_TIMESTAMP,
            version TEXT NOT NULL,
            scores TEXT NOT NULL,
            answers TEXT NOT NULL,
            image_path TEXT NOT NULL
        )
        ''')
        
        # Create some sample data for testing
        cursor.execute('SELECT COUNT(*) FROM results')
        if cursor.fetchone()[0] == 0:
            self._create_sample_data(cursor)
        
        conn.commit()
        conn.close()
    
    def _create_sample_data(self, cursor):
        """Create sample data for testing"""
        sample_data = [
            ('S1001', 'John Smith', 'v1', 
             '{"math": 18, "statistics": 16, "python": 20, "ml": 17, "genai": 19, "total": 90}',
             '["A","B","C","D","A","B","C","D","A","B","A","B","C","D","A","B","C","D","A","B","A","B","C","D","A","B","C","D","A","B","A","B","C","D","A","B","C","D","A","B","A","B","C","D","A","B","C","D","A","B","A","B","C","D","A","B","C","D","A","B","A","B","C","D","A","B","C","D","A","B","A","B","C","D","A","B","C","D","A","B","A","B","C","D","A","B","C","D","A","B","A","B","C","D","A","B","C","D","A","B"]',
             'uploads/sample1.jpg'),
            ('S1002', 'Emma Johnson', 'v1',
             '{"math": 15, "statistics": 14, "python": 18, "ml": 16, "genai": 17, "total": 80}',
             '["A","B","C","D","A","B","C","D","A","B","A","B","C","D","A","B","C","D","A","B","A","B","C","D","A","B","C","D","A","B","A","B","C","D","A","B","C","D","A","B","A","B","C","D","A","B","C","D","A","B","A","B","C","D","A","B","C","D","A","B","A","B","C","D","A","B","C","D","A","B","A","B","C","D","A","B","C","D","A","B","A","B","C","D","A","B","C","D","A","B","A","B","C","D","A","B","C","D","A","B"]',
             'uploads/sample2.jpg'),
            ('S1003', 'Michael Brown', 'v2',
             '{"math": 20, "statistics": 19, "python": 20, "ml": 18, "genai": 20, "total": 97}',
             '["B","A","D","C","B","A","D","C","B","A","B","A","D","C","B","A","D","C","B","A","B","A","D","C","B","A","D","C","B","A","B","A","D","C","B","A","D","C","B","A","B","A","D","C","B","A","D","C","B","A","B","A","D","C","B","A","D","C","B","A","B","A","D","C","B","A","D","C","B","A","B","A","D","C","B","A","D","C","B","A","B","A","D","C","B","A","D","C","B","A","B","A","D","C","B","A","D","C","B","A"]',
             'uploads/sample3.jpg')
        ]
        
        for data in sample_data:
            cursor.execute(
                'INSERT INTO results (student_id, student_name, version, scores, answers, image_path) VALUES (?, ?, ?, ?, ?, ?)',
                data
            )
    
    def get_connection(self):
        """Get a database connection"""
        return sqlite3.connect(self.db_path)
    
    def save_result(self, result_data):
        """Save a result to the database"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        cursor.execute(
            'INSERT INTO results (student_id, student_name, version, scores, answers, image_path) VALUES (?, ?, ?, ?, ?, ?)',
            (
                result_data['student_id'],
                result_data['student_name'],
                result_data['version'],
                json.dumps(result_data['scores']),
                json.dumps(result_data['answers']),
                result_data['image_path']
            )
        )
        
        conn.commit()
        conn.close()
    
    def get_dashboard_stats(self):
        """Get statistics for the dashboard"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        # Total evaluations
        cursor.execute('SELECT COUNT(*) FROM results')
        total_evaluations = cursor.fetchone()[0]
        
        # Total students
        cursor.execute('SELECT COUNT(DISTINCT student_id) FROM results')
        total_students = cursor.fetchone()[0]
        
        # Average score
        cursor.execute('SELECT scores FROM results')
        scores_data = cursor.fetchall()
        
        total_score = 0
        for data in scores_data:
            scores = json.loads(data[0])
            total_score += scores['total']
        
        average_score = round(total_score / total_evaluations) if total_evaluations > 0 else 0
        
        # Score distribution (simplified)
        score_distribution = [12, 35, 120, 240, 180]  # Mock data
        
        # Subject performance (mock data)
        subject_performance = [75, 68, 82, 71, 79]
        
        # Recent evaluations
        cursor.execute('''
            SELECT student_id, student_name, exam_date, scores 
            FROM results 
            ORDER BY exam_date DESC 
            LIMIT 5
        ''')
        recent_data = cursor.fetchall()
        
        recent_evaluations = []
        for data in recent_data:
            scores = json.loads(data[3])
            recent_evaluations.append({
                'student_id': data[0],
                'student_name': data[1],
                'date': data[2],
                'math': scores['math'],
                'statistics': scores['statistics'],
                'python': scores['python'],
                'ml': scores['ml'],
                'genai': scores['genai'],
                'total': scores['total']
            })
        
        conn.close()
        
        return {
            'total_evaluations': total_evaluations,
            'total_students': total_students,
            'average_score': average_score,
            'processing_speed': 3.2,  # Mock data
            'score_distribution': score_distribution,
            'subject_performance': subject_performance,
            'recent_evaluations': recent_evaluations
        }
    
    def get_results(self, search='', page=1, per_page=10):
        """Get paginated results with optional search"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        # Build query based on search
        query = '''
            SELECT id, student_id, student_name, exam_date, scores 
            FROM results 
        '''
        params = []
        
        if search:
            query += ' WHERE student_id LIKE ? OR student_name LIKE ? '
            params.extend([f'%{search}%', f'%{search}%'])
        
        # Add pagination
        query += ' ORDER BY exam_date DESC LIMIT ? OFFSET ? '
        params.extend([per_page, (page - 1) * per_page])
        
        cursor.execute(query, params)
        results_data = cursor.fetchall()
        
        # Format results
        results = []
        for data in results_data:
            scores = json.loads(data[4])
            results.append({
                'id': data[0],
                'student_id': data[1],
                'student_name': data[2],
                'date': data[3],
                'math': scores['math'],
                'statistics': scores['statistics'],
                'python': scores['python'],
                'ml': scores['ml'],
                'genai': scores['genai'],
                'total': scores['total']
            })
        
        # Get total count for pagination
        count_query = 'SELECT COUNT(*) FROM results '
        count_params = []
        
        if search:
            count_query += ' WHERE student_id LIKE ? OR student_name LIKE ? '
            count_params.extend([f'%{search}%', f'%{search}%'])
        
        cursor.execute(count_query, count_params)
        total_count = cursor.fetchone()[0]
        total_pages = (total_count + per_page - 1) // per_page
        
        conn.close()
        
        return {
            'results': results,
            'total_pages': total_pages,
            'current_page': page,
            'total_count': total_count
        }
    
    def get_result_details(self, result_id):
        """Get detailed information for a specific result"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        cursor.execute(
            'SELECT student_id, student_name, exam_date, version, scores, answers, image_path FROM results WHERE id = ?',
            (result_id,)
        )
        
        data = cursor.fetchone()
        if not data:
            return None
        
        scores = json.loads(data[4])
        answers = json.loads(data[5])
        
        conn.close()
        
        return {
            'student_id': data[0],
            'student_name': data[1],
            'date': data[2],
            'version': data[3],
            'math': scores['math'],
            'statistics': scores['statistics'],
            'python': scores['python'],
            'ml': scores['ml'],
            'genai': scores['genai'],
            'total': scores['total'],
            'answers': answers,
            'image_url': data[6]  # In a real app, this would be a URL to the image
        }
    
    def update_result(self, result_id, result_data):
        """Update a result in the database"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        cursor.execute(
            'UPDATE results SET scores = ?, answers = ? WHERE id = ?',
            (
                json.dumps(result_data['scores']),
                json.dumps(result_data['answers']),
                result_id
            )
        )
        
        conn.commit()
        conn.close()
    
    def export_results(self, search=''):
        """Export results as CSV data"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        # Build query based on search
        query = '''
            SELECT student_id, student_name, exam_date, scores 
            FROM results 
        '''
        params = []
        
        if search:
            query += ' WHERE student_id LIKE ? OR student_name LIKE ? '
            params.extend([f'%{search}%', f'%{search}%'])
        
        query += ' ORDER BY exam_date DESC'
        
        cursor.execute(query, params)
        results_data = cursor.fetchall()
        
        # Format results for CSV
        results = []
        for data in results_data:
            scores = json.loads(data[3])
            results.append({
                'student_id': data[0],
                'student_name': data[1],
                'date': data[2],
                'math': scores['math'],
                'statistics': scores['statistics'],
                'python': scores['python'],
                'ml': scores['ml'],
                'genai': scores['genai'],
                'total': scores['total']
            })
        
        conn.close()
        
        return results