from flask import Flask, request, jsonify, send_file
from flask_cors import CORS
import jwt
import datetime
from functools import wraps
import os
from werkzeug.utils import secure_filename
import json

from database import Database
from omr_processor import OMRProcessor

app = Flask(__name__)
app.config['SECRET_KEY'] = 'your-secret-key-here'
app.config['UPLOAD_FOLDER'] = 'uploads'
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max file size

CORS(app)

# Initialize database and OMR processor
db = Database()
omr_processor = OMRProcessor()

# Ensure upload folder exists
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

# Token required decorator
def token_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        token = request.headers.get('Authorization')
        
        if not token:
            return jsonify({'message': 'Token is missing'}), 401
        
        try:
            if token.startswith('Bearer '):
                token = token[7:]
            data = jwt.decode(token, app.config['SECRET_KEY'], algorithms=["HS256"])
        except:
            return jsonify({'message': 'Token is invalid'}), 401
        
        return f(*args, **kwargs)
    
    return decorated

# Routes
@app.route('/api/login', methods=['POST'])
def login():
    data = request.get_json()
    username = data.get('username')
    password = data.get('password')
    
    # Simple authentication (in production, use proper authentication with hashed passwords)
    if username == 'admin' and password == 'admin123':
        token = jwt.encode({
            'user': username,
            'exp': datetime.datetime.utcnow() + datetime.timedelta(hours=24)
        }, app.config['SECRET_KEY'])
        
        return jsonify({
            'success': True,
            'token': token,
            'message': 'Login successful'
        })
    
    return jsonify({
        'success': False,
        'message': 'Invalid credentials'
    }), 401

@app.route('/api/dashboard')
@token_required
def dashboard():
    stats = db.get_dashboard_stats()
    return jsonify(stats)

@app.route('/api/results')
@token_required
def results():
    search = request.args.get('search', '')
    page = request.args.get('page', 1, type=int)
    per_page = 10
    
    results_data = db.get_results(search, page, per_page)
    return jsonify(results_data)

@app.route('/api/results/<int:result_id>')
@token_required
def result_details(result_id):
    result = db.get_result_details(result_id)
    if result:
        return jsonify(result)
    return jsonify({'message': 'Result not found'}), 404

@app.route('/api/process-omr', methods=['POST'])
@token_required
def process_omr():
    if 'file' not in request.files:
        return jsonify({'success': False, 'message': 'No file uploaded'}), 400
    
    file = request.files['file']
    if file.filename == '':
        return jsonify({'success': False, 'message': 'No file selected'}), 400
    
    version = request.form.get('version', 'v1')
    student_id = request.form.get('student_id')
    student_name = request.form.get('student_name')
    
    if not student_id or not student_name:
        return jsonify({'success': False, 'message': 'Student ID and Name are required'}), 400
    
    # Save uploaded file
    filename = secure_filename(file.filename)
    filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
    file.save(filepath)
    
    try:
        # Process OMR
        result = omr_processor.process_omr_sheet(filepath, version)
        
        # Save to database
        db.save_result({
            'student_id': student_id,
            'student_name': student_name,
            'version': version,
            'scores': result['scores'],
            'answers': result['answers'],
            'image_path': filepath
        })
        
        return jsonify({
            'success': True,
            'student_id': student_id,
            'scores': result['scores']
        })
        
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500

@app.route('/api/re-evaluate/<int:result_id>', methods=['POST'])
@token_required
def re_evaluate(result_id):
    try:
        # Get result details from database
        result = db.get_result_details(result_id)
        if not result:
            return jsonify({'success': False, 'message': 'Result not found'}), 404
        
        # Re-process OMR
        new_result = omr_processor.process_omr_sheet(result['image_path'], result['version'])
        
        # Update database
        db.update_result(result_id, {
            'scores': new_result['scores'],
            'answers': new_result['answers']
        })
        
        return jsonify({'success': True, 'message': 'Re-evaluation completed'})
        
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500

@app.route('/api/export-results')
@token_required
def export_results():
    search = request.args.get('search', '')
    results = db.export_results(search)
    
    # Create CSV content
    csv_content = "Student ID,Student Name,Date,Math,Statistics,Python,ML,GenAI,Total\n"
    for result in results:
        csv_content += f"{result['student_id']},{result['student_name']},{result['date']},{result['math']},{result['statistics']},{result['python']},{result['ml']},{result['genai']},{result['total']}\n"
    
    # Create temporary file
    filename = 'omr_results.csv'
    with open(filename, 'w') as f:
        f.write(csv_content)
    
    return send_file(filename, as_attachment=True)

if __name__ == '__main__':
    app.run(debug=True, port=5000)