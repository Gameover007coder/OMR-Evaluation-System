import cv2
import numpy as np
from scipy import ndimage
import json

class OMRProcessor:
    def __init__(self):
        # Define answer keys for different versions
        self.answer_keys = {
            "v1": ["A", "B", "C", "D", "A", "B", "C", "D", "A", "B"] * 10,  # 100 answers
            "v2": ["B", "A", "D", "C", "B", "A", "D", "C", "B", "A"] * 10,
            "v3": ["C", "D", "A", "B", "C", "D", "A", "B", "C", "D"] * 10,
            "v4": ["D", "C", "B", "A", "D", "C", "B", "A", "D", "C"] * 10
        }
        
        self.SUBJECTS = ["Math", "Statistics", "Python", "ML", "GenAI"]
        self.QUESTIONS_PER_SUBJECT = 20
        
    def preprocess_image(self, image):
        """Preprocess the OMR sheet image"""
        # Convert to grayscale
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        
        # Apply Gaussian blur to reduce noise
        blurred = cv2.GaussianBlur(gray, (5, 5), 0)
        
        # Apply adaptive thresholding
        thresh = cv2.adaptiveThreshold(blurred, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, 
                                      cv2.THRESH_BINARY_INV, 11, 2)
        return thresh
    
    def detect_sheet_contour(self, image):
        """Find the OMR sheet contour in the image"""
        # Find contours
        contours, _ = cv2.findContours(image, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        
        # Sort by area and get the largest contour (assuming it's the OMR sheet)
        contours = sorted(contours, key=cv2.contourArea, reverse=True)[:5]
        
        # Approximate the contour
        for contour in contours:
            peri = cv2.arcLength(contour, True)
            approx = cv2.approxPolyDP(contour, 0.02 * peri, True)
            
            # If we have a quadrilateral
            if len(approx) == 4:
                return approx
        
        raise ValueError("Could not detect OMR sheet in the image")
    
    def perspective_transform(self, image, contour):
        """Apply perspective transform to get a top-down view"""
        # Order points consistently
        points = contour.reshape(4, 2)
        rect = np.zeros((4, 2), dtype="float32")
        
        # Top-left and bottom-right points
        s = points.sum(axis=1)
        rect[0] = points[np.argmin(s)]
        rect[2] = points[np.argmax(s)]
        
        # Top-right and bottom-left points
        diff = np.diff(points, axis=1)
        rect[1] = points[np.argmin(diff)]
        rect[3] = points[np.argmax(diff)]
        
        # Define target dimensions (assuming A4 size)
        width, height = 595, 842  # A4 at 72 DPI
        dst = np.array([
            [0, 0],
            [width - 1, 0],
            [width - 1, height - 1],
            [0, height - 1]
        ], dtype="float32")
        
        # Compute perspective transform matrix and apply it
        matrix = cv2.getPerspectiveTransform(rect, dst)
        warped = cv2.warpPerspective(image, matrix, (width, height))
        
        return warped
    
    def detect_bubbles(self, image):
        """Detect and extract bubbles from the OMR sheet"""
        # Find contours in the thresholded image
        contours, _ = cv2.findContours(image, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        
        bubbles = []
        for contour in contours:
            # Filter by area to exclude small noise
            area = cv2.contourArea(contour)
            if 50 < area < 500:  # Adjust based on bubble size
                # Get bounding rectangle
                x, y, w, h = cv2.boundingRect(contour)
                
                # Calculate circularity
                perimeter = cv2.arcLength(contour, True)
                if perimeter > 0:
                    circularity = 4 * np.pi * area / (perimeter * perimeter)
                    if circularity > 0.6:  # Likely a circle
                        bubbles.append({
                            "x": x, 
                            "y": y, 
                            "width": w, 
                            "height": h,
                            "contour": contour
                        })
        
        return bubbles
    
    def extract_answers(self, image, bubbles):
        """Extract answers based on filled bubbles"""
        # Sort bubbles by position (left to right, top to bottom)
        bubbles.sort(key=lambda b: (b["y"] // 50, b["x"]))  # Group by rows
        
        answers = []
        for i in range(100):  # For each question
            # Get the bubbles for this question (typically 4 options: A, B, C, D)
            question_bubbles = bubbles[i*4:(i+1)*4]
            
            # Sort options left to right
            question_bubbles.sort(key=lambda b: b["x"])
            
            # Find which bubble is filled (darkest)
            filled_option = None
            min_intensity = float('inf')
            
            for j, bubble in enumerate(question_bubbles):
                x, y, w, h = bubble["x"], bubble["y"], bubble["width"], bubble["height"]
                roi = image[y:y+h, x:x+w]
                intensity = np.mean(roi)
                
                if intensity < min_intensity:
                    min_intensity = intensity
                    filled_option = j
            
            # Map to answer (0=A, 1=B, 2=C, 3=D)
            answers.append(chr(65 + filled_option) if filled_option is not None else " ")
        
        return answers
    
    def calculate_scores(self, answers, version):
        """Calculate subject-wise scores based on answer key"""
        subject_scores = {subject: 0 for subject in self.SUBJECTS}
        key = self.answer_keys[version]
        
        for i in range(100):
            subject_index = i // self.QUESTIONS_PER_SUBJECT
            subject = self.SUBJECTS[subject_index]
            
            if answers[i] == key[i]:
                subject_scores[subject] += 1
        
        total_score = sum(subject_scores.values())
        
        return {
            "subject_scores": subject_scores,
            "total_score": total_score,
            "answers": answers
        }
    
    def process_omr_sheet(self, image_path, version):
        """Main method to process an OMR sheet"""
        # Load image
        image = cv2.imread(image_path)
        if image is None:
            raise ValueError(f"Could not load image from {image_path}")
        
        # Preprocess image
        processed = self.preprocess_image(image)
        
        # Detect sheet and apply perspective transform
        contour = self.detect_sheet_contour(processed)
        warped = self.perspective_transform(image, contour)
        
        # Preprocess the warped image
        warped_processed = self.preprocess_image(warped)
        
        # Detect bubbles
        bubbles = self.detect_bubbles(warped_processed)
        
        if len(bubbles) < 400:  # Should have at least 100 questions × 4 options
            raise ValueError(f"Detected only {len(bubbles)} bubbles, expected at least 400")
        
        # Extract answers
        answers = self.extract_answers(warped_processed, bubbles)
        
        # Calculate scores
        result = self.calculate_scores(answers, version)
        
        return result

# For testing
if __name__ == "__main__":
    processor = OMRProcessor()
    result = processor.process_omr_sheet("sample_omr.jpg", "v1")
    print(result)